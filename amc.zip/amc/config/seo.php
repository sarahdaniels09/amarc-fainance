<?php return array (
  'meta_image' => 'meta.png',
  'meta_keywords' => 'Amarc Finance investment, invest, investment, Investment Management system',
  'meta_description' => 'Amarc Finance,',
  'social_title' => 'Amarc Finance,',
  'social_description' => 'Amarc Finance,',
);