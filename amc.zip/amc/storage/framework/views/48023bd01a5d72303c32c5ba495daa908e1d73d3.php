<!-- stats-section -->
<section class="stats-section centred">
    <div class="auto-container">
        <div class="row clearfix">
            
           
            <div class="col-lg-3 col-md-6 col-sm-12 single-column">
                <div class="single-item ">
                    <figure class="icon-box"><img src="<?php echo e(asset($themeTrue.'frontend/assets/images/icons/icon-3.png')); ?>" alt=""></figure>
                    <h3>540+ Policies Completed</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 single-column">
                <div class="single-item">
                    <figure class="icon-box"><img src="<?php echo e(asset($themeTrue.'frontend/assets/images/icons/icon-4.png')); ?>" alt=""></figure>
                    <h3>630+ Trusted Customers</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 single-column">
                <div class="single-item">
                    <figure class="icon-box"><img src="<?php echo e(asset($themeTrue.'frontend/assets/images/icons/icon-5.png')); ?>" alt=""></figure>
                    <h3>125+ Opened Locations</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 single-column">
                <div class="single-item">
                    <figure class="icon-box"><img src="<?php echo e(asset($themeTrue.'frontend/assets/images/icons/icon-6.png')); ?>" alt=""></figure>
                    <h3>100% Client Satisfaction</h3>
                </div>
            </div>
        </div>
    </div>
</section>

<?php /**PATH C:\xampp\htdocs\amarc-finance\resources\views/themes/deepblue/sections/feature.blade.php ENDPATH**/ ?>