
    <!-- main-footer -->
    <footer class="main-footer alternet-3">
        
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="copyright"><p>&copy; 2022 <a href="index.html">AMARC FINANCE</a> - Business & Consulting. All rights reserved.</p></div>
            </div>
        </div>
    </footer>
    <!-- main-footer end -->

<?php /**PATH /home/amarumco/public_html/resources/views/themes/deepblue/partials/login-footer.blade.php ENDPATH**/ ?>