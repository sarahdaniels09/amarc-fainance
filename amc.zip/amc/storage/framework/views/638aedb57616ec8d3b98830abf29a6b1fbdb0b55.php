<?php $__env->startSection('content'); ?>

    <!-- contact-style-two -->
    <section class="auth-style-one" style="background-image: url(<?php echo e(asset($themeTrue.'frontend/assets/images/background/contact-3.jpg')); ?>);">
        <div class="auto-container">
            <div class="col-xl-6 col-lg-12 col-md-12 inner-column">
            <div class="row">

               <!--  <div class="default-form pull-left">
                    <figure class="logo"><a href="index.html"><img src="<?php echo e(asset($themeTrue.'frontend/assets/images/logo-6.png')); ?>" alt=""></a></figure>
                <hr>
                </div> -->
            
            </div>

            <form method="post" action="<?php echo e(route('login')); ?>" id="contact-form" class="default-form"> 
                <?php echo csrf_field(); ?>
                <div class="row clearfix">
                        <div class="col-lg-12 col-md-6 col-sm-12">
                            
                            <div class="form-group">
                             <label for="">Username:</label>
                            <input type="text" name="username" placeholder="<?php echo app('translator')->get('Email Or Username'); ?>" required="">
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger  mt-1"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger  mt-1"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                            <div class="form-group">
                            <label for="">Password:</label>
                            <input type="password" name="password" placeholder="<?php echo app('translator')->get('Password'); ?>" required="">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mt-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="remember-me d-flex flex-column flex-sm-row align-items-center justify-content-center justify-content-sm-between mb-30">
                                    <div class="checkbox custom-control custom-checkbox mt-10">
                                        <input id="remember" type="checkbox" class="custom-control-input" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <label class="custom-control-label" for="remember"><?php echo app('translator')->get('Remember Me'); ?></label>
                                    </div>
                                    <a class="text-white mt-10"  href="#"><?php echo app('translator')->get("Forgot password?"); ?></a>
                        </div>

                            <div class="form-group message-btn">
                                <button class="theme-btn style-one" type="submit">Account Login</button>
                            </div>

                            <div class="login-query mt-30 text-center">
                                    <a  href="#"><?php echo app('translator')->get("Don't have any account? Sign Up"); ?></a>
                                </div>
                        </div>
    
                    </div>
                </form>
               
            </div>
        </div>
    </section>
    <!-- contact-style-two end -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make($theme.'layouts.login_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amarumco/public_html/resources/views/themes/deepblue/auth/login.blade.php ENDPATH**/ ?>