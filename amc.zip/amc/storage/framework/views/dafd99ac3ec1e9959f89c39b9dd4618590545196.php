<?php $__env->startSection('title',trans('Profile Settings')); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('navigator'); ?>
        <!-- PAGE-NAVIGATOR -->
        <section id="page-navigator">
            <div class="container-fluid">
                <div aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                        <li class="breadcrumb-item"><a href="javascript:void(0)"
                                                       class="cursor-inherit"><?php echo e(trans('Profile Settings')); ?></a></li>
                    </ol>
                </div>
            </div>
        </section>
        <!-- /PAGE-NAVIGATOR -->
    <?php $__env->stopPush(); ?>

    <section id="dashboard">
        <div class="dashboard-wrapper add-fund pb-50">
            <div class="row">
                <div class="col-sm-4">
                    <div class="card secbg br-4">
                        <div class="card-body br-4">
                            <form method="post" action="<?php echo e(route('user.updateProfile')); ?>"
                                  enctype="multipart/form-data">
                                <div class="form-group">
                                    <?php echo csrf_field(); ?>
                                    <div class="image-input ">
                                        <label for="image-upload" id="image-label"><i
                                                class="fas fa-upload"></i></label>
                                        <input type="file" name="image" placeholder="Choose image" id="image">
                                        <img id="image_preview_container" class="preview-image"
                                             style="max-width: 200px"
                                             src="<?php echo e(getFile(config('location.user.path').$user->image)); ?>"
                                             alt="preview image">
                                    </div>
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <h3><?php echo app('translator')->get(ucfirst($user->name)); ?></h3>
                                <p><?php echo app('translator')->get('Joined At'); ?> <?php echo app('translator')->get($user->created_at->format('d M, Y g:i A')); ?></p>
                                <div class="submit-btn-wrapper text-center text-md-left">
                                    <button type="submit" class=" btn btn-primary base-btn btn-block btn-rounded">
                                        <span><?php echo app('translator')->get('Image Update'); ?></span></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-sm-8">
                    <div class="card secbg form-block br-4">
                        <div class="card-body">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e($errors->has('profile') ? 'active' : ($errors->has('password') ? '' : 'active')); ?>"
                                       data-toggle="tab" href="#home"><?php echo app('translator')->get('Profile Information'); ?></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e($errors->has('password') ? 'active' : ''); ?>"
                                       data-toggle="tab"
                                       href="#menu1"><?php echo app('translator')->get('Password Setting'); ?></a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content ">
                                <div id="home"
                                     class="container mt-4 tab-pane <?php echo e($errors->has('profile') ? 'active' : ($errors->has('password') ? '' : 'active')); ?>">
                                    <form action="<?php echo e(route('user.updateInformation')); ?>" method="post">
                                        <?php echo method_field('put'); ?>
                                        <?php echo csrf_field(); ?>

                                        <div class="row ">
                                            <div class="col-md-6">
                                                <div class="form-group ">
                                                    <label><?php echo app('translator')->get('First Name'); ?></label>
                                                    <input class="form-control" type="text" name="firstname"
                                                           value="<?php echo e(old('firstname')?: $user->firstname); ?>">
                                                    <?php if($errors->has('firstname')): ?>
                                                        <div
                                                            class="error text-danger"><?php echo app('translator')->get($errors->first('firstname')); ?> </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group ">
                                                    <label><?php echo app('translator')->get('Last Name'); ?></label>
                                                    <input class="form-control" type="text" name="lastname"
                                                           value="<?php echo e(old('lastname')?: $user->lastname); ?>">
                                                    <?php if($errors->has('lastname')): ?>
                                                        <div
                                                            class="error text-danger"><?php echo app('translator')->get($errors->first('lastname')); ?> </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group ">
                                                    <label><?php echo app('translator')->get('Username'); ?></label>
                                                    <input class="form-control" type="text" name="username"
                                                           value="<?php echo e(old('username')?: $user->username); ?>">
                                                    <?php if($errors->has('username')): ?>
                                                        <div
                                                            class="error text-danger"><?php echo app('translator')->get($errors->first('username')); ?> </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group ">
                                                    <label><?php echo app('translator')->get('Email Address'); ?></label>
                                                    <input class="form-control" type="email"
                                                           value="<?php echo e($user->email); ?>" readonly>
                                                    <?php if($errors->has('email')): ?>
                                                        <div
                                                            class="error text-danger"><?php echo app('translator')->get($errors->first('email')); ?> </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group ">
                                                    <label><?php echo app('translator')->get('Phone Number'); ?></label>
                                                    <input class="form-control" type="text" readonly
                                                           value="<?php echo e($user->phone); ?>">

                                                    <?php if($errors->has('phone')): ?>
                                                        <div
                                                            class="error text-danger"><?php echo app('translator')->get($errors->first('phone')); ?> </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                           
                                        </div>

                                        <div class="form-group ">
                                            <label><?php echo app('translator')->get('Address'); ?></label>
                                            <textarea class="form-control" name="address"
                                                      rows="5"><?php echo app('translator')->get($user->address); ?></textarea>

                                            <?php if($errors->has('address')): ?>
                                                <div
                                                    class="error text-danger"><?php echo app('translator')->get($errors->first('address')); ?> </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="submit-btn-wrapper text-center text-md-left">
                                            <button type="submit"
                                                    class="btn btn-primary base-btn btn-block btn-rounded">
                                                <span><?php echo app('translator')->get('Update User'); ?></span></button>
                                        </div>
                                    </form>
                                </div>


                                <div id="menu1"
                                     class="container mt-4 tab-pane <?php echo e($errors->has('password') ? 'active' : ''); ?>">

                                    <form method="post" action="<?php echo e(route('user.updatePassword')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group mt-4">
                                            <label><?php echo app('translator')->get('Current Password'); ?></label>
                                            <input id="password" type="password" class="form-control"
                                                   name="current_password" autocomplete="off">
                                            <?php if($errors->has('current_password')): ?>
                                                <div
                                                    class="error text-danger"><?php echo app('translator')->get($errors->first('current_password')); ?> </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group mt-4">
                                            <label><?php echo app('translator')->get('New Password'); ?></label>
                                            <input id="password" type="password" class="form-control"
                                                   name="password" autocomplete="off">
                                            <?php if($errors->has('password')): ?>
                                                <div
                                                    class="error text-danger"><?php echo app('translator')->get($errors->first('password')); ?> </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group ">
                                            <label><?php echo app('translator')->get('Confirm Password'); ?></label>
                                            <input id="password_confirmation" type="password"
                                                   name="password_confirmation" autocomplete="off"
                                                   class="form-control">
                                            <?php if($errors->has('password_confirmation')): ?>
                                                <div
                                                    class="error text-danger"><?php echo app('translator')->get($errors->first('password_confirmation')); ?> </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="submit-btn-wrapper text-center">
                                            <button type="submit"
                                                    class=" btn btn-primary base-btn btn-block btn-rounded">
                                                <span><?php echo app('translator')->get('Update Password'); ?></span></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        $(document).on('click', '#image-label', function () {
            $('#image').trigger('click');
        });
        $(document).on('change', '#image', function () {
            var _this = $(this);
            var newimage = new FileReader();
            newimage.readAsDataURL(this.files[0]);
            newimage.onload = function (e) {
                $('#image_preview_container').attr('src', e.target.result);
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($theme.'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amarc-finance\resources\views/themes/deepblue/user/profile/myprofile.blade.php ENDPATH**/ ?>